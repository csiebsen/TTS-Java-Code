package com.acme;

import com.acme.bo.Customer;
import com.acme.bo.Employee;

public class Controller {

	Customer customer;
	Employee employee;
	
	protected void runDemo() {
		loadData();
		showStatus();
	}
	
	private void loadData() {
		customer = new Customer("Arnold","Schwarzeneger","pump@yaoo.com","12345");
		employee = new Employee("Danny","Devito","dd@yaoo.com","23456", 123458,"123121234");
	}
	
	private void showStatus() {
		System.out.println(customer.toString());
		System.out.println(employee.toString());
	}
	
}

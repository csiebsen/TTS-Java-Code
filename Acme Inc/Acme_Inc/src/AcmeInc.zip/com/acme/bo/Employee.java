package com.acme.bo;

public class Employee {
	
	private String firstName;
	private String lastName;
	private String email;
	private String employeeId;
	private double salary;
	private String ssn;
	

	public Employee(String firstName, String lastName, String email, String employeeId, double salary, String ssn) {

		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setEmail(email);
		this.setEmployeeId(employeeId);
		this.setSalary(salary);
		this.setSsn(ssn);
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		int pos = email.indexOf(".");
		
		if (!email.contains("@") || !email.contains(".")) {
			throw new RuntimeException("Email must have a @ and . character [" + email + "]");
		}
		this.email = email;
	}

	
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	
	public void setEmployeeId(String employeeId) {

		try {
			Integer.parseInt(employeeId);
		} catch (NumberFormatException e) {
			throw new RuntimeException("Emplyee number must be numeric [" + employeeId + "]");
		}

		this.employeeId = employeeId;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		String output = "";
		output = output + "Name: " + getFirstName() + " " + getLastName();
		output = output + "\nEmail: " + getEmail();
		output = output + "\nId: " + getEmployeeId();
		output = output + "\nSalary: " + getSalary();
		output = output + "\nSSN: " + getSsn();
		
		return output;
	}
	
}
